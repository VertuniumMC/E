
local phaseaccum = pd.Class:new():register("accum~")

local TWO_PI = 6.283185307179586
local PI = 3.141592653589793
local floor = math.floor

function phaseaccum:initialize(sel, atoms)
    self.inlets = {SIGNAL, SIGNAL}
    self.outlets = {SIGNAL}

    local size = tonumber(atoms[1]) or 1024
    local overlap = tonumber(atoms[2]) or 8

    if size < 1 or overlap < 1 then
        return false
    end

    self.fft_size = size
    self.overlap = overlap

    self.phase = {}
    self.outbuf = {}
    self.initialized = false

    return true
end

function phaseaccum:dsp(samplerate, blocksize)
    self.bs = blocksize
    self.phase_scale =
        TWO_PI * self.fft_size /
        (self.overlap * samplerate)

    self.initialized = false
end

function phaseaccum:reset()
    self.initialized = false
end

function phaseaccum:perform(freq, seed)
    local phase = self.phase
    local out = self.outbuf
    local n = #freq

    if not self.initialized then
        for i = 1, n do
            local p = seed[i] or 0
            p = p - TWO_PI * floor((p + PI) / TWO_PI)

            phase[i] = p
            out[i] = p
        end

        self.initialized = true
        return out
    end

    local scale = self.phase_scale

    for i = 1, n do
        local p = phase[i] + freq[i] * scale

        p = p - TWO_PI * floor((p + PI) / TWO_PI)

        phase[i] = p
        out[i] = p
    end

    return out
end

return phaseaccum
